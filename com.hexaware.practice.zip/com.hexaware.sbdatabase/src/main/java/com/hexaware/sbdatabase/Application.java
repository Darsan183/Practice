package com.hexaware.sbdatabase;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


import com.hexaware.sbdatabase.UserRepo.UserRepository;

import com.hexaware.sbdatabase.Entities.User;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
       ApplicationContext  context=SpringApplication.run(Application.class, args);
		
       UserRepository rep=	context.getBean(UserRepository.class);
		
       
		
       /*
       User user1= new User();
		user1.setUserId(102);
		user1.setName("ajay");
		
		user1.setFee(8000.9);
		rep.save(user1);
		*/
		
		 Iterable<User> users = rep.findAll();
	       users.forEach((temp)-> System.out.println(temp.toString()));
	       
		
		  /*
	       Optional<User>u= rep.findById(102);
			
			System.out.println(u);
			if(u.isPresent())
			{
				rep.deleteById(102);

				
			}
			else
			{
				System.out.println("Not Found");
			}
			*/
       
       /*Optional<User> u=	rep.findById(100);
   	
  	     if(u.isPresent())
  	     {
  		
  		    User temp=u.get();
  		    
  		   temp.setName("jatin");
  		   rep.save(temp);
  		
  	     }
  	    else
  	   {
  		 System.out.println("Not Found");
  	   }*/
	}

}
