package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entities.Employee;
import com.example.demo.Entities.PayrollPolicy;
import com.example.demo.Service.PayrollPolicyService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/payrollpolicies")
public class PayrollPolicyController {

    @Autowired
    private PayrollPolicyService payrollPolicyService;

    @PostMapping("/create")
    public ResponseEntity<PayrollPolicy> createPayrollPolicy(@Valid @RequestBody PayrollPolicy payrollPolicy) {
        PayrollPolicy savedPayrollPolicy = payrollPolicyService.savePayrollPolicy(payrollPolicy);
        return new ResponseEntity<>(savedPayrollPolicy, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<PayrollPolicy>> getPayrollPolicies() {
        List<PayrollPolicy> payrollPolicies = payrollPolicyService.getAllPayrollPolicies();
        return new ResponseEntity<>(payrollPolicies, HttpStatus.OK);
    }

    @GetMapping("/getbyId/{id}")
    public ResponseEntity<PayrollPolicy> getPayrollPolicyById(@PathVariable Long id) {
        PayrollPolicy payrollPolicy = payrollPolicyService.getPayrollPolicyById(id);
        if (payrollPolicy != null) {
            return new ResponseEntity<>(payrollPolicy, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateTaxRate/{id}")
    public ResponseEntity<PayrollPolicy> updateTaxRate(
        @PathVariable Long id,
        @RequestParam Double taxRate) {
        PayrollPolicy updatedPayrollPolicy = payrollPolicyService.updateTaxRate(id, taxRate);
        if (updatedPayrollPolicy != null) {
            return new ResponseEntity<>(updatedPayrollPolicy, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateBonusRate/{id}")
    public ResponseEntity<PayrollPolicy> updateBonusRate(
        @PathVariable Long id,
        @RequestParam Double bonusRate) {
        PayrollPolicy updatedPayrollPolicy = payrollPolicyService.updateBonusRate(id, bonusRate);
        if (updatedPayrollPolicy != null) {
            return new ResponseEntity<>(updatedPayrollPolicy, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @PostMapping("/assign/{policyId}/{employeeId}")
    public ResponseEntity<Employee> assignPolicyToEmployee(@PathVariable Long policyId, @PathVariable Long employeeId) {
        Employee updatedEmployee = payrollPolicyService.assignPolicyToEmployeeAndUpdatePayrolls(policyId, employeeId);
        if (updatedEmployee != null) {
            return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/remove/{policyId}/{employeeId}")
    public ResponseEntity<Void> removePolicyFromEmployee(@PathVariable Long policyId, @PathVariable Long employeeId) {
        payrollPolicyService.removePolicyFromEmployee(policyId, employeeId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> removePayrollPolicy(@PathVariable Long id) {
        boolean isDeleted = payrollPolicyService.deletePayrollPolicy(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @GetMapping("/employee/{employeeId}/policies")
    public ResponseEntity<List<PayrollPolicy>> getPoliciesOfEmployee(@PathVariable Long employeeId) {
        List<PayrollPolicy> policies = payrollPolicyService.getPoliciesOfEmployee(employeeId);
        if (policies != null && !policies.isEmpty()) {
            return new ResponseEntity<>(policies, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
