package com.example.demo.Entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;

@Entity
@Table(name = "payroll_policies")
public class PayrollPolicy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String policyName;

    
    @Column(nullable = false)
    @DecimalMin(value = "0.0",message = "Tax rate must be greater than 0")
    @DecimalMax(value = "100.0",message = "Tax rate must be less than or equal to 100")
    private Double taxRate;

    
    @Column(nullable = false)
    @DecimalMin(value = "0.0",message = "Bonus rate must be greater than 0")
    @DecimalMax(value = "100.0",message = "Bonus rate must be less than or equal to 100")
    private Double bonusRate;

    @ManyToMany(mappedBy = "policies")
    @JsonIgnore
    private List<Employee> employees = new ArrayList();
    
    @OneToMany(mappedBy = "payrollPolicy", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Payroll> payrolls;

    // Default constructor
    public PayrollPolicy() {}

    // Parameterized constructor
    public PayrollPolicy(String policyName, Double taxRate, Double bonusRate, List<Payroll> payrolls) {
        this.policyName = policyName;
        this.taxRate = taxRate;
        this.bonusRate = bonusRate;
        this.payrolls = payrolls;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPolicyName() { return policyName; }
    public void setPolicyName(String policyName) { this.policyName = policyName; }

    public Double getTaxRate() { return taxRate; }
    public void setTaxRate(Double taxRate) { this.taxRate = taxRate; }

    public Double getBonusRate() { return bonusRate; }
    public void setBonusRate(Double bonusRate) { this.bonusRate = bonusRate; }

    public List<Payroll> getPayrolls() { return payrolls; }
    public void setPayrolls(List<Payroll> payrolls) { this.payrolls = payrolls; }
    
    

    public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
    public String toString() {
        return "PayrollPolicy [id=" + id + ", policyName=" + policyName + ", taxRate=" + taxRate + ", bonusRate="
                + bonusRate + ", payrolls=" + payrolls + "]";
    }
}
