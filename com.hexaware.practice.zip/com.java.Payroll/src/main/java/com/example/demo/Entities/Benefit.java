package com.example.demo.Entities;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name = "benefits")
public class Benefit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String benefitName;

    private Double contribution;

    @ManyToMany(mappedBy = "benefits")
    @JsonIgnore
    private List<Employee> employee = new ArrayList();

   
    // Default constructor
    public Benefit() {}

    // Parameterized constructor (excluding id)
    public Benefit(String benefitName, Double contribution) {
        this.benefitName = benefitName;
        this.contribution = contribution;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBenefitName() { return benefitName; }
    public void setBenefitName(String benefitName) { this.benefitName = benefitName; }

    public Double getContribution() { return contribution; }
    public void setContribution(Double contribution) { this.contribution = contribution; }

    public List<Employee> getEmployees() { return employee; }
    public void setEmployees(List<Employee> employees) { this.employee = employees; }

    @Override
    public String toString() {
        return "Benefit [id=" + id + ", benefitName=" + benefitName + ", contribution=" + contribution + ", employees=" + employee + "]";
    }
}
