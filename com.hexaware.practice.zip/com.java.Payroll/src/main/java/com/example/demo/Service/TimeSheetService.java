package com.example.demo.Service;

import com.example.demo.Entities.TimeSheet;
import com.example.demo.Dao.TimeSheetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TimeSheetService {

    @Autowired
    private TimeSheetRepository timeSheetRepository;

    public TimeSheet saveTimeSheet(TimeSheet timeSheet) {
        return timeSheetRepository.save(timeSheet);
    }

    public List<TimeSheet> getAllTimeSheets() {
        return timeSheetRepository.findAll();
    }

    public TimeSheet getTimeSheetById(Long id) {
        return timeSheetRepository.findById(id).orElse(null);
    }

    public TimeSheet updateTimeSheet(Long id, TimeSheet timeSheet) {
        if (timeSheetRepository.existsById(id)) {
            timeSheet.setId(id);
            return timeSheetRepository.save(timeSheet);
        }
        return null;
    }

    public boolean deleteTimeSheet(Long id) {
        if (timeSheetRepository.existsById(id)) {
            timeSheetRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
