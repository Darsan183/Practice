package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entities.TimeSheet;
import com.example.demo.Service.TimeSheetService;

import jakarta.validation.Valid;

import java.util.List;


@RestController
@RequestMapping("/timesheets")
public class TimeSheetController {

    @Autowired
    private TimeSheetService timeSheetService;

    @PostMapping("/create")
    public ResponseEntity<TimeSheet> createTimeSheet(@Valid @RequestBody TimeSheet timeSheet) {
        TimeSheet savedTimeSheet = timeSheetService.saveTimeSheet(timeSheet);
        return new ResponseEntity<>(savedTimeSheet, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<TimeSheet>> getTimeSheets() {
        List<TimeSheet> timeSheets = timeSheetService.getAllTimeSheets();
        return new ResponseEntity<>(timeSheets, HttpStatus.OK);
    }

    @GetMapping("/getbyId/{id}")
    public ResponseEntity<TimeSheet> getTimeSheetById(@PathVariable Long id) {
        TimeSheet timeSheet = timeSheetService.getTimeSheetById(id);
        if (timeSheet != null) {
            return new ResponseEntity<>(timeSheet, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<TimeSheet> updateTimeSheet(@PathVariable Long id, @RequestBody TimeSheet timeSheet) {
        TimeSheet updatedTimeSheet = timeSheetService.updateTimeSheet(id, timeSheet);
        if (updatedTimeSheet != null) {
            return new ResponseEntity<>(updatedTimeSheet, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> removeTimeSheet(@PathVariable Long id) {
        boolean isDeleted = timeSheetService.deleteTimeSheet(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
