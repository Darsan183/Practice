package com.example.demo.Service;

import com.example.demo.Entities.Benefit;
import com.example.demo.Entities.Employee;
import com.example.demo.Dao.BenefitRepository;
import com.example.demo.Dao.EmployeeRepository;
import com.example.demo.Dao.PayrollRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BenefitService {

    @Autowired
    private BenefitRepository benefitRepository;
    

    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private PayrollRepository payrollRepository;
    
    public Benefit saveBenefit(Benefit benefit) {
        return benefitRepository.save(benefit);
    }

    public List<Benefit> getAllBenefits() {
        return benefitRepository.findAll();
    }

    public Benefit getBenefitById(Long id) {
        return benefitRepository.findById(id).orElse(null);
    }

    public Benefit updateContribution(Long benefitId, Double newContribution) {
        // Find the Benefit by ID
        Benefit benefit = benefitRepository.findById(benefitId).orElse(null);
        
        if (benefit != null) {
            // Update the Benefit contribution
            benefit.setContribution(newContribution);
            benefitRepository.save(benefit);

            // Find all employees who have this Benefit
            List<Employee> employees = employeeRepository.findByBenefitsContaining(benefit);

            // Update deductions and save payrolls for all these employees
            employees.forEach(employee -> {
                employee.getPayrolls().forEach(payroll -> {
                    payroll.updateDeductionsFromBenefits(); // Recalculate deductions
                    payroll.calculateAndStoreTotalSalary(); // Recalculate total salary
                    payrollRepository.save(payroll); // Save updated payroll
                });
            });

            return benefit;
        }

        return null;
    }


    public boolean deleteBenefit(Long id) {
        if (benefitRepository.existsById(id)) {
            benefitRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    public Benefit assignBenefitsToEmployee(Long benefitId, Long employeeId) {
        Benefit benefit = benefitRepository.findById(benefitId).orElse(null);
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        
        if (benefit != null && employee != null) {
            if (!employee.getBenefits().contains(benefit)) {
                employee.getBenefits().add(benefit);
                employeeRepository.save(employee);
            }
            return benefit;
        }
        return null;
    }

    public void removeBenefitFromEmployee(Long benefitId, Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        Benefit benefit = benefitRepository.findById(benefitId).orElse(null);

        if (employee != null && benefit != null) {
            // Remove the benefit from the employee's list of benefits
            employee.getBenefits().remove(benefit);

            // Update payroll deductions associated with the employee
            employee.getPayrolls().forEach(payroll -> {
                payroll.updateDeductionsFromBenefits();  // Update deductions based on remaining benefits
                payroll.calculateAndStoreTotalSalary();  // Recalculate total salary after deduction update
                payrollRepository.save(payroll);         // Save the updated payroll
            });

            // Save the updated employee
            employeeRepository.save(employee);
        }
    }

    
    public List<Benefit> getBenefitsOfEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        return (employee != null) ? employee.getBenefits() : null;
    }


}
