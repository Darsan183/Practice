package com.example.demo.Service;

import com.example.demo.Entities.Payroll;
import com.example.demo.Entities.PayrollPolicy;
import com.example.demo.Dao.PayrollPolicyRepository;
import com.example.demo.Dao.PayrollRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PayrollService {

    @Autowired
    private PayrollRepository payrollRepository;
    
    @Autowired
    private PayrollPolicyRepository payrollPolicyRepository;

    public Payroll savePayroll(Payroll payroll) {
        return payrollRepository.save(payroll);
    }

    public List<Payroll> getAllPayrolls() {
        return payrollRepository.findAll();
    }

    public Payroll getPayrollById(Long id) {
        return payrollRepository.findById(id).orElse(null);
    }

    public Payroll updateTaxAndBonus(Long payrollId) {
        Payroll payroll = payrollRepository.findById(payrollId).orElse(null);
        if (payroll != null) {
            PayrollPolicy policy = payrollPolicyRepository.findById(payroll.getPayrollPolicy().getId()).orElse(null);
            if (policy != null) {
                double baseSalary = payroll.getBaseSalary();
                double taxRate = policy.getTaxRate();
                double bonusRate = policy.getBonusRate();

                double tax = baseSalary * taxRate / 100;
                double bonus = baseSalary * bonusRate / 100;

                payroll.setTax(tax);
                payroll.setBonus(bonus);
                payroll.calculateAndStoreTotalSalary(); // This method should be updated to calculate total salary

                return payrollRepository.save(payroll);
            }
        }
        return null;
    }
    
    public boolean deletePayroll(Long id) {
        if (payrollRepository.existsById(id)) {
            payrollRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
