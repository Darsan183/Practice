package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entities.Employee;
import com.example.demo.Entities.Payroll;
import com.example.demo.Service.EmployeeService;
import com.example.demo.Service.PayrollService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/payrolls")
public class PayrollController {

    @Autowired
    private PayrollService payrollService;

    @PostMapping("/create")
    public ResponseEntity<Payroll> createPayroll(@Valid @RequestBody Payroll payroll) {
        Payroll savedPayroll = payrollService.savePayroll(payroll);
        return new ResponseEntity<>(savedPayroll, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Payroll>> getPayrolls() {
        List<Payroll> payrolls = payrollService.getAllPayrolls();
        return new ResponseEntity<>(payrolls, HttpStatus.OK);
    }

    @GetMapping("/getbyId/{id}")
    public ResponseEntity<Payroll> getPayrollById(@PathVariable Long id) {
        Payroll payroll = payrollService.getPayrollById(id);
        if (payroll != null) {
            return new ResponseEntity<>(payroll, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateTaxAndBonus/{id}")
    public ResponseEntity<Payroll> updateTaxAndBonus(@PathVariable Long id) {
        Payroll updatedPayroll = payrollService.updateTaxAndBonus(id);
        if (updatedPayroll != null) {
            return new ResponseEntity<>(updatedPayroll, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> removePayroll(@PathVariable Long id) {
        boolean isDeleted = payrollService.deletePayroll(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    
}
