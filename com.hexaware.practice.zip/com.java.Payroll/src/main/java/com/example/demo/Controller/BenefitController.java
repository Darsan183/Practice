package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entities.Benefit;
import com.example.demo.Service.BenefitService;

import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/benefits")
public class BenefitController {

    @Autowired
    private BenefitService benefitService;

    @PostMapping("/create")
    public ResponseEntity<Benefit> createBenefit(@Valid @RequestBody Benefit benefit) {
        Benefit savedBenefit = benefitService.saveBenefit(benefit);
        return new ResponseEntity<>(savedBenefit, HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Benefit>> getBenefits() {
        List<Benefit> benefits = benefitService.getAllBenefits();
        return new ResponseEntity<>(benefits, HttpStatus.OK);
    }

    @GetMapping("/getbyId/{id}")
    public ResponseEntity<Benefit> getBenefitById(@PathVariable Long id) {
        Benefit benefit = benefitService.getBenefitById(id);
        if (benefit != null) {
            return new ResponseEntity<>(benefit, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/updateContribution/{benefitId}")
    public ResponseEntity<Benefit> updateContribution(@PathVariable Long benefitId, @RequestParam Double newContribution) {
        Benefit updatedBenefit = benefitService.updateContribution(benefitId, newContribution);
        if (updatedBenefit != null) {
            return new ResponseEntity<>(updatedBenefit, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> removeBenefit(@PathVariable Long id) {
        boolean isDeleted = benefitService.deleteBenefit(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    
    @PostMapping("/assign/{benefitId}/{employeeId}")
    public ResponseEntity<Benefit> assignBenefitToEmployee(@PathVariable Long benefitId, @PathVariable Long employeeId) {
        Benefit updatedBenefit = benefitService.assignBenefitsToEmployee(benefitId, employeeId);
        if (updatedBenefit != null) {
            return new ResponseEntity<>(updatedBenefit, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/remove/{benefitId}/{employeeId}")
    public ResponseEntity<Void> removeBenefitFromEmployee(@PathVariable Long benefitId, @PathVariable Long employeeId) {
        benefitService.removeBenefitFromEmployee(benefitId, employeeId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<List<Benefit>> getBenefitsOfEmployee(@PathVariable Long employeeId) {
        List<Benefit> benefits = benefitService.getBenefitsOfEmployee(employeeId);
        if (benefits != null) {
            return new ResponseEntity<>(benefits, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }


}
