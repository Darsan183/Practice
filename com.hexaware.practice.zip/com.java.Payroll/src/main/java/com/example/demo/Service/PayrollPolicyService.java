package com.example.demo.Service;

import com.example.demo.Entities.Employee;
import com.example.demo.Entities.Payroll;
import com.example.demo.Entities.PayrollPolicy;
import com.example.demo.Dao.EmployeeRepository;
import com.example.demo.Dao.PayrollPolicyRepository;
import com.example.demo.Dao.PayrollRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PayrollPolicyService {

    @Autowired
    private PayrollPolicyRepository payrollPolicyRepository;
    
    @Autowired
    private EmployeeRepository employeeRepository;
    
    @Autowired
    private PayrollRepository payrollRepository;

    public PayrollPolicy savePayrollPolicy(PayrollPolicy payrollPolicy) {
        return payrollPolicyRepository.save(payrollPolicy);
    }

    public List<PayrollPolicy> getAllPayrollPolicies() {
        return payrollPolicyRepository.findAll();
    }

    public PayrollPolicy getPayrollPolicyById(Long id) {
        return payrollPolicyRepository.findById(id).orElse(null);
    }

    public PayrollPolicy updateTaxRate(Long id, Double taxRate) {
        PayrollPolicy payrollPolicy = payrollPolicyRepository.findById(id).orElse(null);
        if (payrollPolicy != null) {
            payrollPolicy.setTaxRate(taxRate);
            payrollPolicyRepository.save(payrollPolicy);

            // Update related Payrolls
            updatePayrollsBasedOnPolicy(payrollPolicy);

            return payrollPolicy;
        }
        return null;
    }

    public PayrollPolicy updateBonusRate(Long id, Double bonusRate) {
        PayrollPolicy payrollPolicy = payrollPolicyRepository.findById(id).orElse(null);
        if (payrollPolicy != null) {
            payrollPolicy.setBonusRate(bonusRate);
            payrollPolicyRepository.save(payrollPolicy);

            // Update related Payrolls
            updatePayrollsBasedOnPolicy(payrollPolicy);

            return payrollPolicy;
        }
        return null;
    }

    private void updatePayrollsBasedOnPolicy(PayrollPolicy payrollPolicy) {
        // Find all Payrolls associated with the updated policy
        List<Payroll> payrolls = payrollRepository.findByPayrollPolicy(payrollPolicy);

        // Update each Payroll using the updatePayrollDetails method
        payrolls.forEach(payroll -> {
            payroll.updatePayrollDetails(payrollPolicy); // Reuse the utility method in Payroll class
            payrollRepository.save(payroll); // Save updated payroll
        });
    }


    public Employee assignPolicyToEmployeeAndUpdatePayrolls(Long policyId, Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        PayrollPolicy payrollPolicy = payrollPolicyRepository.findById(policyId).orElse(null);

        if (employee != null && payrollPolicy != null) {
            // Add PayrollPolicy to Employee's list of policies if not already present
            if (!employee.getPolicies().contains(payrollPolicy)) {
                employee.getPolicies().add(payrollPolicy);
            }

            // Update Payroll details using the utility method
            employee.getPayrolls().forEach(payroll -> {
                if (payroll.getPayrollPolicy().equals(payrollPolicy)) {
                    payroll.updatePayrollDetails(payrollPolicy);
                    payrollRepository.save(payroll);  // Save the updated payroll
                }
            });

            // Save the updated employee with the new policy
            return employeeRepository.save(employee);
        }
        return null;
    }

    
    public void removePolicyFromEmployee(Long policyId, Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        PayrollPolicy payrollPolicy = payrollPolicyRepository.findById(policyId).orElse(null);

        if (employee != null && payrollPolicy != null) {
            // Remove the policy from employee's policies
            employee.getPolicies().remove(payrollPolicy);

            // Update payrolls to reset tax and bonus
            employee.getPayrolls().forEach(payroll -> {
                if (payroll.getPayrollPolicy().equals(payrollPolicy)) {
                    payroll.setTax(0.0);  // Reset tax
                    payroll.setBonus(0.0); // Reset bonus
                    payroll.calculateAndStoreTotalSalary();  // Recalculate total salary
                    payrollRepository.save(payroll);
                }
            });

            // Save the updated employee
            employeeRepository.save(employee);
        }
    }



    public boolean deletePayrollPolicy(Long id) {
        if (payrollPolicyRepository.existsById(id)) {
            payrollPolicyRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    public List<PayrollPolicy> getPoliciesOfEmployee(Long employeeId) {
        Employee employee = employeeRepository.findById(employeeId).orElse(null);
        if (employee != null) {
            return new ArrayList<>(employee.getPolicies());
        }
        return null;
    }
    
}
