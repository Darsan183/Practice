package com.example.demo.Entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name = "payrolls")
public class Payroll {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    @JsonIgnore
    private Employee employee;

    @ManyToOne
    @JoinColumn(name = "payroll_policy_id", nullable = false)
    @JsonIgnore
    private PayrollPolicy payrollPolicy;
    
    private Double baseSalary;

    private Double tax=0.0;

    private Double bonus=0.0;

    private Double deductions=0.0;

    private Double totalSalary;

    // Default constructor
    public Payroll() {}

    // Parameterized constructor (excluding totalSalary)
    public Payroll(Employee employee, PayrollPolicy payrollPolicy, Double baseSalary, Double tax, Double bonus, Double deductions) {
        this.employee = employee;
        this.payrollPolicy = payrollPolicy;
        this.baseSalary = baseSalary;
        this.tax = tax != null ? tax : 0.0;
        this.bonus = bonus != null ? bonus : 0.0;
        this.deductions = deductions != null ? deductions : 0.0;
        calculateAndStoreTotalSalary(); // Calculate total salary during initialization
    }

    // Method to calculate and store total salary
    public void calculateAndStoreTotalSalary() {
        this.totalSalary = baseSalary + bonus - (tax + deductions);
    }
    
    public void updateDeductionsFromBenefits() {
        if (employee != null && employee.getBenefits() != null) {
            double totalDeductions = employee.getBenefits()
                .stream()
                .mapToDouble(Benefit::getContribution)
                .sum();
            this.deductions = totalDeductions;
        }
        calculateAndStoreTotalSalary(); // Update total salary after deduction change
    }
    
    public void updatePayrollDetails(PayrollPolicy payrollPolicy) {
        double baseSalary = this.getBaseSalary();
        double taxRate = payrollPolicy.getTaxRate();
        double bonusRate = payrollPolicy.getBonusRate();

        // Calculate tax and bonus
        double tax = baseSalary * taxRate / 100;
        double bonus = baseSalary * bonusRate / 100;

        // Set tax and bonus
        this.setTax(tax);
        this.setBonus(bonus);

        // Update deductions from benefits
        this.updateDeductionsFromBenefits();

        // Calculate and store total salary
        this.calculateAndStoreTotalSalary();
    }


    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    public PayrollPolicy getPayrollPolicy() { return payrollPolicy; }
    public void setPayrollPolicy(PayrollPolicy payrollPolicy) { this.payrollPolicy = payrollPolicy; }

    public Double getBaseSalary() { return baseSalary; }
    
    public void setBaseSalary(Double baseSalary) {
        this.baseSalary = baseSalary;
        calculateAndStoreTotalSalary(); // Recalculate total salary when baseSalary changes
    }

    public Double getTax() { return tax; }
    public void setTax(Double tax) {
        this.tax = tax;
        calculateAndStoreTotalSalary(); // Recalculate total salary when tax changes
    }

    public Double getBonus() { return bonus; }
    public void setBonus(Double bonus) {
        this.bonus = bonus;
        calculateAndStoreTotalSalary(); // Recalculate total salary when bonus changes
    }

    public Double getDeductions() { return deductions; }
    public void setDeductions(Double deductions) {
        this.deductions = deductions;
        calculateAndStoreTotalSalary(); // Recalculate total salary when deductions change
    }

    public Double getTotalSalary() { return totalSalary; }

	@Override
	public String toString() {
		return "Payroll [id=" + id + ", payrollPolicy=" + payrollPolicy + ", baseSalary=" + baseSalary + ", tax=" + tax
				+ ", bonus=" + bonus + ", deductions=" + deductions + ", totalSalary=" + totalSalary + "]";
	}

    
}
