package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class UserController {

    @Autowired
    private UserDataService service;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome this endpoint is not secure";
    }

    @PostMapping("/addNewUser")
    public String addNewUser(@RequestBody UserData userInfo) {
        return service.addUser(userInfo);
    }

    @GetMapping("/employee/employeeProfile")
    @PreAuthorize("hasAuthority('ROLE_EMPLOYEE')")
    public String employeeProfile() {
        return "Welcome to Employee Profile!";
    }

    @GetMapping("/payroll/payrollProfile")
    @PreAuthorize("hasAuthority('ROLE_PAYROLL_PROCESSOR')")
    public String payrollProcessorProfile() {
        return "Welcome to Payroll Processor Profile!";
    }

    @GetMapping("/manager/managerProfile")
    @PreAuthorize("hasAuthority('ROLE_MANAGER')")
    public String managerProfile() {
        return "Welcome to Manager Profile!";
    }

    @GetMapping("/admin/adminProfile")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String adminProfile() {
        return "Welcome to Admin Profile!";
    }

    @PostMapping("/generateToken")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
        if (authentication.isAuthenticated()) {
            return jwtService.generateToken(authRequest.getUsername());
        } else {
            throw new UsernameNotFoundException("invalid user request !");
        }
    }

    @PutMapping("/updatePassword/{id}")
    public ResponseEntity<UserData> updatePassword(@PathVariable Long id, @RequestBody String newPassword) {
        UserData updatedUser = service.updatePassword(id, passwordEncoder.encode(newPassword));
        return ResponseEntity.ok(updatedUser);
    }
}