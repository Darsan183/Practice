package com.example.demo.Entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
@Table(name = "timesheets")
public class TimeSheet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date workDate;

    @Column(nullable = false)
    private Double hoursWorked;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    @JsonIgnore
    private Employee employee;

    // Default constructor
    public TimeSheet() {}

    // Parameterized constructor (excluding id)
    public TimeSheet(Date workDate, Double hoursWorked, Employee employee) {
        this.workDate = workDate;
        this.hoursWorked = hoursWorked;
        this.employee = employee;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Date getWorkDate() { return workDate; }
    public void setWorkDate(Date workDate) { this.workDate = workDate; }

    public Double getHoursWorked() { return hoursWorked; }
    public void setHoursWorked(Double hoursWorked) { this.hoursWorked = hoursWorked; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    @Override
    public String toString() {
        return "TimeSheet [id=" + id + ", workDate=" + workDate + ", hoursWorked=" + hoursWorked + ", employee="
                + employee + "]";
    }
}
