package com.example.demo.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entities.Employee;
import com.example.demo.Entities.Payroll;
import com.example.demo.Entities.PayrollPolicy;

@Repository
public interface PayrollRepository extends JpaRepository<Payroll, Long> {

	List<Payroll> findByEmployee(Employee employee);

	List<Payroll> findByPayrollPolicy(PayrollPolicy payrollPolicy);
    
	
}

