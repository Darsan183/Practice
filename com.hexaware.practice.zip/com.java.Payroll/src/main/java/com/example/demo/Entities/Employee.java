package com.example.demo.Entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.example.demo.UserData;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    @Email
    private String email;

    @Column(nullable = false, unique = true)
    private String phoneNumber;

    @Column(nullable = false)
    private String department;

    @Column(nullable = false)
    private String position;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date hireDate;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserData user;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Payroll> payrolls = new ArrayList<>();

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<LeaveRequest> leaveRequests = new ArrayList<>();

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<TimeSheet> timesheets = new ArrayList<>();

    @ManyToMany
    @JsonIgnore
    @JoinTable(
      name = "employee_benefit",
      joinColumns = @JoinColumn(name = "employee_id"),
      inverseJoinColumns = @JoinColumn(name = "benefit_id"))
    private List<Benefit> benefits = new ArrayList<>();

    
    @ManyToMany
    @JoinTable(
      name = "employee_policy",
      joinColumns = @JoinColumn(name = "employee_id"),
      inverseJoinColumns = @JoinColumn(name = "policy_id")
    )
    private List<PayrollPolicy> policies = new ArrayList<>();
    // Default constructor
    
    
    public Employee() {}

    // Parameterized constructor (excluding collections)
    public Employee(String name, String email, String phoneNumber, String department, String position, Date hireDate, UserData user) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.department = department;
        this.position = position;
        this.hireDate = hireDate;
        this.user = user;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public Date getHireDate() { return hireDate; }
    public void setHireDate(Date hireDate) { this.hireDate = hireDate; }

    public UserData getUser() { return user; }
    public void setUser(UserData user) { this.user = user; }

    public List<Payroll> getPayrolls() { return payrolls; }
    public void setPayrolls(List<Payroll> payrolls) { this.payrolls = payrolls; }

    public List<LeaveRequest> getLeaveRequests() { return leaveRequests; }
    public void setLeaveRequests(List<LeaveRequest> leaveRequests) { this.leaveRequests = leaveRequests; }

    public List<TimeSheet> getTimesheets() { return timesheets; }
    public void setTimesheets(List<TimeSheet> timesheets) { this.timesheets = timesheets; }

    public List<Benefit> getBenefits() { return benefits; }
    public void setBenefits(List<Benefit> benefits) { this.benefits = benefits; }

    public List<PayrollPolicy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<PayrollPolicy> policies) {
		this.policies = policies;
	}

	@Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", phoneNumber=" + phoneNumber
                + ", department=" + department + ", position=" + position + ", hireDate=" + hireDate + "]";
    }
}
